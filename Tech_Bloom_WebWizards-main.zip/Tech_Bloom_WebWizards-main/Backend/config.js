// backend/config.js
module.exports = {
  MONGO_URI: 'mongodb+srv://Deeksha:DeekshaMargi@shopease.u78maks.mongodb.net/',
  JWT_SECRET: 'c5ce4af9586338bb63290dc1315abf57d07b62540df2d1db439a76479ecc3051'
};
