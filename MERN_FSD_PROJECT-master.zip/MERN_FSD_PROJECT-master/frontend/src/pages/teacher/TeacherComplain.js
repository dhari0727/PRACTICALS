import React from 'react'

const TeacherComplain = () => {
  return (
    <div>TeacherComplain</div>
  )
}

export default TeacherComplain